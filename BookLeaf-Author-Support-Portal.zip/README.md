# BookLeaf Author Support Portal

A role-based publishing support portal for authors and BookLeaf support administrators. Authors can review book and royalty information, open tickets, and follow replies. Administrators can triage a shared queue, assign and update tickets, keep private notes, and prepare reviewed replies.

## Stack

- Frontend: React 18, React Router, Vite
- Backend: Node.js 18+, Express, MySQL 8, Zod
- Authentication: signed JWT in an HttpOnly cookie
- Optional AI: Google Gemini API via Google AI Studio, called only by the backend

## Local setup

1. Install Node.js 18+ and MySQL 8.
2. Run `npm install` from `backend/`, then create a private `backend/.env` based on `.env.example`.
3. Set `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, a long random `JWT_SECRET`, and non-default `SEED_AUTHOR_PASSWORD` and `SEED_ADMIN_PASSWORD` values. Keep `.env` private and do not commit it.
4. Start MySQL and run `npm run seed` from `backend/`. The seed script validates the supplied sample-data royalty arithmetic, applies the schema and migrations, and idempotently upserts the provided books, authors, and two admin accounts.
5. Start the API with `npm run dev` from `backend/` (default `http://localhost:4000`).
6. Run `npm install` from `frontend/`, then `npm run dev` (default `http://localhost:5173`).
7. Open `http://localhost:5173/login`. Seeded author accounts use the shared `SEED_AUTHOR_PASSWORD`; admin accounts use `SEED_ADMIN_PASSWORD`. For example, `priya.sharma@email.com` is an author login and `admin@bookleafpublishing.com` is an admin login.

The seed command writes to the database named by `DB_NAME`. Verify that name and take a backup before running it against any database containing important data. The integration test creates and drops a uniquely named test database and requires a MySQL account permitted to create/drop databases; it does not use the configured application database.

For AI features, create an API key in [Google AI Studio](https://aistudio.google.com/apikey), then set `GEMINI_API_KEY` in the private `backend/.env` file. The default `GEMINI_MODEL` is `gemini-3.5-flash-lite`; override it only with a model enabled for your account. AI Studio offers free-tier access subject to model availability, region, and quotas, so Google may reject requests when free limits are reached. Never commit or send the key in chat. Google's free-tier data terms may allow submitted content to be used to improve its products; use fictional/demo tickets with a free-tier key and do not submit confidential or sensitive author information unless your organization's terms and consent allow it. Without a key, ticket submission and manual triage/replies continue to work; AI triage is marked as skipped and administrators can respond manually. Configure `CLIENT_ORIGIN` to the exact frontend origin. In production, serve over HTTPS and set a strong `JWT_SECRET`.

Ticket files can be uploaded when creating a ticket or later from its detail page. The supported formats, limits, private storage location, and access rules are described below and in [docs/API.md](./docs/API.md).

## Commands

From `backend/`:

```text
npm run dev
npm start
npm run seed
npm run test:unit
npm test
```

From `frontend/`:

```text
npm run dev
npm run build
npm run preview
```

The frontend build compiles the static SPA into `frontend/dist`. Deploy it with a static host configured to serve `index.html` for client-side routes. Configure `VITE_API_BASE` to the API origin when frontend and API are on different hosts; the client appends `/api/v1`.

## Access and privacy

The seed process creates 20 demo author accounts from the sample dataset and provisions two administrator accounts (`admin@bookleafpublishing.com` and `operations@bookleafpublishing.com`). Set their shared initial password through `SEED_ADMIN_PASSWORD` and rotate it after deployment. Author initial passwords come from `SEED_AUTHOR_PASSWORD`; distribute credentials securely and rotate them before production use. The `example.com` sample author addresses are demo identities, not mailboxes.

Session JWTs are not returned to JavaScript or stored in local storage. Ticket attachments support PDF, JPG, PNG, GIF, WEBP, MP4, MOV, and WEBM files (up to five files, 25 MB each). Files are stored outside the public web root in `backend/private-uploads/`; back up this directory alongside the database and use persistent private storage in production. Downloads require an authenticated ticket owner or admin. Internal notes and AI rationale are restricted to the admin API. See [docs/API.md](./docs/API.md) and [docs/APPROACH.md](./docs/APPROACH.md).
